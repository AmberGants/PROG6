/*import javax.swing.JOptionPane;

public class secondJOption {
    public static void main(String[] args) {
        String message = "STUDENT MANAGEMENT APPLICATION\n_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _\nEnter (1) to launch menu or any other key to exit";
        String title = "Student Management App";

        while (true) {
            String userInput = JOptionPane.showInputDialog(null, message, title, JOptionPane.QUESTION_MESSAGE);

            if (userInput == null || !userInput.equals("1")) {
                JOptionPane.showMessageDialog(null, "Exiting application...");
                break;
            }

            String menu = "Select an option:\n"
                    + "(1) Capture a new student\n"
                    + "(2) Search for a student\n"
                    + "(3) Delete a student\n"
                    + "(4) Print student report\n"
                    + "(5) Exit Application";

            String menuChoice = JOptionPane.showInputDialog(null, menu, title, JOptionPane.QUESTION_MESSAGE);

            switch (menuChoice) {
                case "1":
                    JOptionPane.showMessageDialog(null, "Capture new student selected!");
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Search for student selected!");
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Delete student selected!");
                    break;
                case "4":
                    JOptionPane.showMessageDialog(null, "Print student report selected!");
                    break;
                case "5":
                    JOptionPane.showMessageDialog(null, "Exiting application...");
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option selected!");
            }
        }

    }
}*/
