/*import org.junit.Before;
import org.junit.Test;

import javax.swing.*;

import static org.junit.Assert.*;



public class test {
    private String student;
    private int age;
    private String email;
    private int  ID;

    @Before
    public void setUp() {
        forth.studentCount = 0;
    }
    @Test
    public void testCaptureNewStudent() {
        forth.captureNewStudent();
        assertEquals(1, forth.studentCount);
    }

    @Test
    public void testSearchStudentFound() {
        forth.captureNewStudent();
        String searchID = JOptionPane.showInputDialog(null, "Enter Student ID to search:");
        String result = forth.searchStudent(searchID);
        assertNotNull(result);
    }

    @Test
    public void testSearchStudentNotFound() {
        String searchID = JOptionPane.showInputDialog(null, "Enter Student ID to search:");
        String result = forth.searchStudent(searchID);
        assertNull(result);
    }

    @Test
    public void testDeleteStudent() {
        forth.captureNewStudent();
        String deleteID = JOptionPane.showInputDialog(null, "Enter Student ID to delete:");
        boolean result = forth.deleteStudent(deleteID);
        assertTrue(result);
    }
    @Test
    public void testPrintStudentReport() {
        forth.captureNewStudent();
        String report = forth.printStudentReport();
        assertNotNull(report);*/
    }




}
