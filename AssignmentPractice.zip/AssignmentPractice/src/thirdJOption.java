/*import javax.swing.JOptionPane;


public class thirdJOption {
    private static String[][] students = new String[100][5]; // array to store student data
    private static int studentCount = 0; // counter for number of students




    public static void main(String[] args) {
        while (true) {
            String message = "STUDENT MANAGEMENT APPLICATION\n\nEnter (1) to launch menu or any other key to exit";
            String userInput = JOptionPane.showInputDialog(null, message, "Student Management App", JOptionPane.QUESTION_MESSAGE);

            if (userInput == null || !userInput.equals("1")) {
                JOptionPane.showMessageDialog(null, "Exiting application...");
                break;
            }

            String menu = "Select an option:\n"
                    + "(1) Capture a new student\n"
                    + "(2) Search for a student\n"
                    + "(3) Delete a student\n"
                    + "(4) Print student report\n"
                    + "(5) Exit Application";

            String menuChoice = JOptionPane.showInputDialog(null, menu, "Student Management App", JOptionPane.QUESTION_MESSAGE);

            switch (menuChoice) {
                case "1":
                    captureNewStudent();
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Search for student selected!");
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Delete student selected!");
                    break;
                case "4":
                    JOptionPane.showMessageDialog(null, "Print student report selected!");
                    break;
                case "5":
                    JOptionPane.showMessageDialog(null, "Exiting application...");
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option selected!");
            }
        }
    }

    private static void captureNewStudent() {
        String studentID = JOptionPane.showInputDialog(null, "Enter Student ID:", "Capture New Student", JOptionPane.QUESTION_MESSAGE);
        String studentName = JOptionPane.showInputDialog(null, "Enter Student Name:", "Capture New Student", JOptionPane.QUESTION_MESSAGE);

        int studentAge;
        while (true) {
            try {
                studentAge = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Student Age:", "Capture New Student", JOptionPane.QUESTION_MESSAGE));
                if (studentAge < 16) {
                    JOptionPane.showMessageDialog(null, "You entered an incorrect student age!!! Please re-enter the Student age. The age should be greater or equal to 16");

                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid age entered! Please try again.");
            }
        }

        String studentEmail = JOptionPane.showInputDialog(null, "Enter Student Email:", "Capture New Student", JOptionPane.QUESTION_MESSAGE);
        String studentCourse = JOptionPane.showInputDialog(null, "Enter Student Course:", "Capture New Student", JOptionPane.QUESTION_MESSAGE);


        int studentCount;
        students[studentCount][0] = studentID;
        students[studentCount][1] = studentName;
        students[studentCount][2] = String.valueOf(studentAge);
        students[studentCount][3] = studentEmail;
        students[studentCount][4] = studentCourse;
        studentCount++;


        JOptionPane.showMessageDialog(null, "Student captured successfully!");


        private static void searchStudent () {
            String searchID = JOptionPane.showInputDialog(null, "Enter Student ID to search:", "Search Student", JOptionPane.QUESTION_MESSAGE);
            boolean found = false;
            for (int i = 0; i < studentCount; i++) {
                if (students[i][0].equals(searchID)) {
                    JOptionPane.showMessageDialog(null, "Student found!\n" +
                            "Name: " + students[i][1] + "\n" +
                            "Age: " + students[i][2] + "\n" +
                            "Email: " + students[i][3] + "\n" +
                            "Course: " + students[i][4]);
                    found = true;
                    break;
                }
            }
            if (!found) {
                JOptionPane.showMessageDialog(null, "Student not found!");
            }
        }

        private static void deleteStudent () {
            String deleteID = JOptionPane.showInputDialog(null, "Enter Student ID to delete:", "Delete Student", JOptionPane.QUESTION_MESSAGE);
            boolean found = false;
            for (int i = 0; i < studentCount; i++) {
                if (students[i][0].equals(deleteID)) {
                    for (int j = i; j < studentCount - 1; j++) {
                        students[j][0] = students[j + 1][0];
                        students[j][1] = students[j + 1][1];
                        students[j][2] = students[j + 1][2];
                        students[j][3] = students[j + 1][3];
                        students[j][4] = students[j + 1][4];
                    }

                    studentCount--;
                    JOptionPane.showMessageDialog(null, "Student deleted successfully!");
                    found = true;
                    break;
                }
            }


            String message = "STUDENT MANAGEMENT APPLICATION\n\nEnter (1) to launch menu or any other key to exit";
            String userInput = JOptionPane.showInputDialog(null, message, "Student Management App", JOptionPane.QUESTION_MESSAGE);
            if (userInput == null || !userInput.equals("1")) {
                JOptionPane.showMessageDialog(null, "Exiting application...");
                System.exit(0);
            }
        }
    }
}*/

