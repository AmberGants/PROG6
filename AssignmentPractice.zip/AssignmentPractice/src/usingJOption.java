import javax.swing.JOptionPane;

public class usingJOption {
    public static void main(String[] args) {
        String message = "STUDENT MANAGEMENT APPLICATION\n_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _\nEnter (1) to launch menu or any other key to exit";

        String title = "Student Management App";

        String userInput = JOptionPane.showInputDialog(null, message,  title, JOptionPane.QUESTION_MESSAGE);

        if (userInput != null && userInput.equals("1")) {
            JOptionPane.showMessageDialog(null, "Menu launched!");
        } else {
            JOptionPane.showMessageDialog(null, "Exiting application...");
        }




    }
}
