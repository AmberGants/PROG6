import java.util.ArrayList;
import java.util.List;


// Parent class: Beverage
class Beverage {
    protected String name;
    protected double price;

    public Beverage(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}

// Child class: Coffee extends Beverage
class Coffee extends Beverage {
    private String type;

    public Coffee(String name, double price, String type) {
        super(name, price);
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
    public void sellCoffee(String name) {
    for (Coffee coffee : coffees) {
        if (coffee.getName().equals(name)) {
            System.out.println("Sold: " + coffee.getName() + " - $" + coffee.getPrice());
            printReceipt(coffee);
            return;
            }
        }
        System.out.println("Coffee not found!");
    }

    private void printReceipt(Coffee coffee) {
    System.out.println("Receipt:");
    System.out.println("Name: " + coffee.getName());
    System.out.println("Price: $" + coffee.getPrice());
    System.out.println("Type: " + coffee.getType());
}
    public static void main(String[] args) {
    CoffeeShop coffeeShop = new CoffeeShop();
    coffeeShop.displayMenu();

    // Simulate a sale
    coffeeShop.sellCoffee("Latte");
    }
}


